<template>
  <div class="home">
    <!-- <Com0></Com0> -->
    <SafetyEco v-bind:data="text"></SafetyEco>
  </div>
</template>

<script>
// @ is an alias to /src
// import HelloWorld from '@/components/HelloWorld.vue';
// import Com0 from '@/components/TestCom.vue';
import SafetyEco from '@/components/Service_SafetyEco.vue';

export default {
  name: 'about',
  components: {
    // Com0,
    SafetyEco,
  },
  data() {
    return {
      text: {
        SafetyRoute: '246',
        ECORoute: '123',
      },
    };
  },
};
</script>

<style lang="scss" scoped></style>
