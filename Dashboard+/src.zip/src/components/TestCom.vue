<template>
  <div class="hello">
    <h3>{{ msg }}</h3>
  </div>
</template>

<script>
export default {
  name: "component0",
  data() {
    return {
      msg: "TestComponent",
    };
  },
};
</script>
