<template>
  <div class="hello">
    <h3>
      Safety Route <br /><br />
      {{ data.SafetyRoute }}
    </h3>
    <br />
    <h3>ECO Route <br /><br />{{ data.ECORoute }}</h3>
  </div>
</template>

<script>
export default {
  name: 'Header',
  props: {
    data: Object,
  },
};
</script>
